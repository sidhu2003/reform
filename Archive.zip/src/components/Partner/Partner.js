import React from "react";
import image1 from "./Images/Frame 9.png";
import image2 from "./Images/Frame 12.png";
import image3 from "./Images/Frame 13.png";
import image4 from "./Images/Frame 14.png";
import image5 from "./Images/Frame 15.png";
import styles from "./styles.module.css";

export default function Partner() {
  return (
    <div className={styles.partner_container}>
      <div className={styles.logos}>
        {/* <img src={image1} alt="partner_logo" />
        <img src={image2} alt="partner_logo" />
        <img src={image3} alt="partner_logo" />
        <img src={image4} alt="partner_logo" />
        <img src={image5} alt="partner_logo" /> */}
      </div>
    </div>
  );
}
